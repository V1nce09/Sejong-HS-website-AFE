import os
import sqlite3
from datetime import datetime
from flask import (
    Blueprint, render_template, request, redirect, url_for,
    flash, current_app, g, session
)
from werkzeug.utils import secure_filename

board_bp = Blueprint("board", __name__, url_prefix="/board")

# -----------------------------
# DB 연결
# -----------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


# -----------------------------
# 게시판 목록
# -----------------------------
@board_bp.route("/<grade>/<classroom>")
def board_list(grade, classroom):
    db = get_db()
    posts = db.execute(
        "SELECT * FROM posts WHERE grade = ? AND classroom = ? ORDER BY created_at DESC",
        (grade, classroom),
    ).fetchall()

    user = session.get("user")
    user_data = None
    if user:
        user_data = db.execute("SELECT * FROM users WHERE userid = ?", (user,)).fetchone()

    return render_template(
        "board_list.html",
        posts=posts,
        grade=grade,
        classroom=classroom,
        user=user,
        user_data=user_data,  # ✅ 추가
    )


# -----------------------------
# 게시글 보기
# -----------------------------
@board_bp.route('/<int:grade>/<int:classroom>/<int:post_id>')
def post_detail(grade, classroom, post_id):
    db = get_db()
    post = db.execute("SELECT * FROM posts WHERE id=?", (post_id,)).fetchone()
    comments = db.execute("SELECT * FROM comments WHERE post_id=? ORDER BY created_at ASC", (post_id,)).fetchall()

    user = session.get("user")
    user_data = None
    if user:
        user_data = db.execute("SELECT * FROM users WHERE userid = ?", (user,)).fetchone()

    return render_template(
        'post_detail.html',
        post=post,
        comments=comments,
        grade=grade,
        classroom=classroom,
        user=user,
        user_data=user_data  # ✅ 반드시 추가!
    )


# -----------------------------
# 게시글 작성
# -----------------------------
@board_bp.route("/<grade>/<classroom>/new", methods=["GET", "POST"])
@board_bp.route("/<grade>/<classroom>/new", methods=["GET", "POST"])
def new_post(grade, classroom):
    db = get_db()
    user = session.get("user")
    user_data = None
    if user:
        user_data = db.execute("SELECT * FROM users WHERE userid = ?", (user,)).fetchone()

    if request.method == "POST":
        title = request.form["title"]
        content = request.form["content"]
        author = user if user else "익명"
        image = request.files.get("image")

        image_path = None
        if image and image.filename != "":
            filename = secure_filename(image.filename)
            upload_folder = os.path.join(current_app.root_path, "static", "uploads")
            os.makedirs(upload_folder, exist_ok=True)
            image_path = os.path.join("static", "uploads", filename)
            image.save(os.path.join(upload_folder, filename))

        db.execute(
            "INSERT INTO posts (title, content, author, grade, classroom, image_path, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (title, content, author, grade, classroom, image_path, datetime.now().isoformat()),
        )
        db.commit()
        flash("게시글이 등록되었습니다.")
        return redirect(url_for("board.board_list", grade=grade, classroom=classroom))

    # ✅ user_data를 템플릿에 넘겨준다!
    return render_template(
        "post_form.html",
        edit=False,
        grade=grade,
        classroom=classroom,
        user=user,
        user_data=user_data
    )

# -----------------------------
# 게시글 수정
# -----------------------------
@board_bp.route("/<grade>/<classroom>/<int:post_id>/edit", methods=["GET", "POST"])
@board_bp.route('/<int:grade>/<int:classroom>/<int:post_id>/edit', methods=['GET', 'POST'])
def post_edit(grade, classroom, post_id):
    db = get_db()
    post = db.execute("SELECT * FROM posts WHERE id=?", (post_id,)).fetchone()

    user = session.get("user")
    user_data = None
    if user:
        user_data = db.execute("SELECT * FROM users WHERE userid = ?", (user,)).fetchone()

    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        image = request.files.get('image')

        image_path = post['image_path']
        if image and image.filename != "":
            filename = secure_filename(image.filename)
            upload_folder = os.path.join(current_app.root_path, 'static', 'uploads')
            os.makedirs(upload_folder, exist_ok=True)
            image_path = os.path.join('static', 'uploads', filename)
            image.save(os.path.join(upload_folder, filename))

        db.execute(
            "UPDATE posts SET title=?, content=?, image_path=? WHERE id=?",
            (title, content, image_path, post_id)
        )
        db.commit()
        flash("게시글이 수정되었습니다.")
        return redirect(url_for('board.post_detail', grade=grade, classroom=classroom, post_id=post_id))

    # ✅ user, user_data 추가 전달!
    return render_template(
        "post_form.html",
        post=post,
        edit=True,
        grade=grade,
        classroom=classroom,
        user=user,
        user_data=user_data
    )

# -----------------------------
# 게시글 삭제
# -----------------------------
@board_bp.route("/<grade>/<classroom>/<int:post_id>/delete", methods=["POST"])
def post_delete(grade, classroom, post_id):
    db = get_db()
    db.execute("DELETE FROM posts WHERE id=?", (post_id,))
    db.execute("DELETE FROM comments WHERE post_id=?", (post_id,))
    db.commit()
    flash("게시글이 삭제되었습니다.")
    return redirect(url_for("board.board_list", grade=grade, classroom=classroom))


# -----------------------------
# 댓글 작성
# -----------------------------
@board_bp.route("/<grade>/<classroom>/<int:post_id>/comment", methods=["POST"])
def comment_add(grade, classroom, post_id):
    db = get_db()
    author = session.get("user", "익명")
    content = request.form["content"]
    db.execute(
        "INSERT INTO comments (post_id, author, content, created_at) VALUES (?, ?, ?, ?)",
        (post_id, author, content, datetime.now().isoformat()),
    )
    db.commit()
    return redirect(url_for("board.post_detail", grade=grade, classroom=classroom, post_id=post_id))


# -----------------------------
# 댓글 삭제
# -----------------------------
@board_bp.route("/<grade>/<classroom>/<int:post_id>/comment/<int:comment_id>/delete", methods=["POST"])
def comment_delete(grade, classroom, post_id, comment_id):
    db = get_db()
    db.execute("DELETE FROM comments WHERE id=?", (comment_id,))
    db.commit()
    return redirect(url_for("board.post_detail", grade=grade, classroom=classroom, post_id=post_id))
