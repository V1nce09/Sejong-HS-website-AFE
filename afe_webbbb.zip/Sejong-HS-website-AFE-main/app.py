from flask import Flask, render_template, request, redirect, url_for, jsonify, session
from datetime import datetime, timedelta
import requests
from bs4 import BeautifulSoup
import time

app = Flask(__name__)
app.secret_key = "secret"

# NEIS API 정보
API_KEY = "e940bcda8d8e44d2a2d72d3b3c0a0e63"
ATPT_OFCDC_SC_CODE = "I10"
SD_SCHUL_CODE = "9300054"
SEM = "2"

#캐싱 설정 및 저장소
CACHE_LIFETIME = 3600
meal_cache = {}
timetable_cache = {}

# 급식
def get_meal(date):
    cache_key = date
    
    if cache_key in meal_cache:
        cached_data, timestamp = meal_cache[cache_key]
        if time.time() - timestamp < CACHE_LIFETIME:
            print(f"급식 정보 캐시 히트: {date}")
            return cached_data
        else:
            print(f"급식 정보 캐시 만료: {date}")

    print(f"급식 정보 API 호출: {date}")
    url = (
        f"https://open.neis.go.kr/hub/mealServiceDietInfo"
        f"?KEY={API_KEY}&Type=xml&pIndex=1&pSize=100"
        f"&ATPT_OFCDC_SC_CODE={ATPT_OFCDC_SC_CODE}"
        f"&SD_SCHUL_CODE={SD_SCHUL_CODE}&MLSV_YMD={date}"
    )
    
    try:
        info = requests.get(url, timeout=5).text
        soup = BeautifulSoup(info, "xml")
        
        if soup.find("RESULT") and soup.find("CODE").text != "INFO-000":

            meal_data = [] 
        else:
            meal_data = []
            times = [t.text for t in soup.find_all("MMEAL_SC_NM")]
            menus = [m.text.replace("<br/>", "\n") for m in soup.find_all("DDISH_NM")]
            for t, m in zip(times, menus):
                meal_data.append({"time": t, "menu": m})

        meal_cache[cache_key] = (meal_data, time.time())
        return meal_data

    except requests.exceptions.RequestException as e:
        print(f"API 요청 오류: {e}")
        return []

#시간표
def get_timetable(date, grade, classroom):

    cache_key = f"{date}_{grade}_{classroom}"

    if cache_key in timetable_cache:
        cached_data, timestamp = timetable_cache[cache_key]
        if time.time() - timestamp < CACHE_LIFETIME:
            print(f"시간표 캐시 히트: {cache_key}")
            return cached_data
        else:
            print(f"시간표 캐시 만료: {cache_key}")

    print(f"시간표 API 호출: {cache_key}")
    url = (
        f"https://open.neis.go.kr/hub/hisTimetable"
        f"?KEY={API_KEY}&Type=xml&pIndex=1&pSize=100"
        f"&ATPT_OFCDC_SC_CODE={ATPT_OFCDC_SC_CODE}"
        f"&SD_SCHUL_CODE={SD_SCHUL_CODE}&SEM={SEM}"
        f"&GRADE={grade}&CLASS_NM={classroom}&ALL_TI_YMD={date}"
    )

    try:
        info = requests.get(url, timeout=5).text
        soup = BeautifulSoup(info, "xml")

        if soup.find("RESULT") and soup.find("CODE").text != "INFO-000":
            timetable = []
        else:
            timetable = [i.text for i in soup.find_all("ITRT_CNTNT")]

        timetable_cache[cache_key] = (timetable, time.time())
        return timetable

    except requests.exceptions.RequestException as e:
        print(f"API 요청 오류: {e}")
        return []

#로그인 사이트
@app.route("/login", methods=["GET", "POST"])
def login(): #이거 로그인 시스템 어떻게 만드는거임?

    if request.method == "POST":
        userid = request.form["userid"]
        password = request.form["password"]
        if userid == "admin" and password == "1234": #이렇게하는거였음?
            session["user"] = userid
            return redirect(url_for("main"))
        else:
            return render_template("login.html", error="아이디 또는 비밀번호가 올바르지 않습니다.")

    return render_template("login.html")

#메인
@app.route("/main")
def main():
    if "user" not in session:
        return redirect(url_for("login"))
    return render_template("main.html")

#API 데이터 요청
@app.route("/api/data", methods=["GET"])
def api_data():
    date = request.args.get("date", datetime.now().strftime("%Y%m%d"))
    grade = request.args.get("grade", "1")
    classroom = request.args.get("classroom", "1")

    start_date = datetime.strptime(date, "%Y%m%d")
    days = [(start_date + timedelta(days=i)).strftime("%Y%m%d") for i in range(0, 14)]

    week_data = []
    for d in days:

        timetable = get_timetable(d, grade, classroom)
        if timetable:
            week_data.append({"date": d, "timetable": timetable})

    meal_data = get_meal(date)

    return jsonify({
        "meal": meal_data,
        "timetable": week_data,
        "grade": grade,
        "classroom": classroom,
        "date": date
    })


if __name__ == "__main__":
    app.run(debug=True)