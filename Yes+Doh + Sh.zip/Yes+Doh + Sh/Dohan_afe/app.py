from flask import Flask, render_template, request, redirect, url_for, jsonify, session, g
from datetime import datetime, timedelta
import requests, sqlite3, os, time
from bs4 import BeautifulSoup
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "secret-key"
DATABASE = os.path.join(os.path.dirname(__file__), "users.db")

API_KEY = "e940bcda8d8e44d2a2d72d3b3c0a0e63"
ATPT_OFCDC_SC_CODE = "I10"
SD_SCHUL_CODE = "9300054"
SEM = "2"

CACHE_LIFETIME = 3600
meal_cache = {}
timetable_cache = {}

# ------------------ DB ------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db:
        db.close()

def init_db():
    db = sqlite3.connect(DATABASE)
    cur = db.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userid TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        grade TEXT,
        classroom TEXT,
        student_no TEXT,
        created_at TEXT NOT NULL
    )
    """)
    db.commit()
    db.close()

init_db()

# ------------------ API ------------------
def get_meal(date):
    cache_key = date
    if cache_key in meal_cache:
        data, t = meal_cache[cache_key]
        if time.time() - t < CACHE_LIFETIME:
            return data
    url = f"https://open.neis.go.kr/hub/mealServiceDietInfo?KEY={API_KEY}&Type=xml&pIndex=1&pSize=100&ATPT_OFCDC_SC_CODE={ATPT_OFCDC_SC_CODE}&SD_SCHUL_CODE={SD_SCHUL_CODE}&MLSV_YMD={date}"
    try:
        xml = requests.get(url, timeout=5).text
        soup = BeautifulSoup(xml, "xml")
        meal_data = []
        if not (soup.find("RESULT") and soup.find("CODE").text != "INFO-000"):
            for t, m in zip(soup.find_all("MMEAL_SC_NM"), soup.find_all("DDISH_NM")):
                meal_data.append({"time": t.text, "menu": m.text.replace("<br/>", "\n")})
        meal_cache[cache_key] = (meal_data, time.time())
        return meal_data
    except:
        return []

def get_timetable(date, grade, classroom):
    cache_key = f"{date}_{grade}_{classroom}"
    if cache_key in timetable_cache:
        data, t = timetable_cache[cache_key]
        if time.time() - t < CACHE_LIFETIME:
            return data
    url = f"https://open.neis.go.kr/hub/hisTimetable?KEY={API_KEY}&Type=xml&pIndex=1&pSize=100&ATPT_OFCDC_SC_CODE={ATPT_OFCDC_SC_CODE}&SD_SCHUL_CODE={SD_SCHUL_CODE}&SEM={SEM}&GRADE={grade}&CLASS_NM={classroom}&ALL_TI_YMD={date}"
    try:
        xml = requests.get(url, timeout=5).text
        soup = BeautifulSoup(xml, "xml")
        if soup.find("RESULT") and soup.find("CODE").text != "INFO-000":
            return []
        timetable = [i.text for i in soup.find_all("ITRT_CNTNT")]
        timetable_cache[cache_key] = (timetable, time.time())
        return timetable
    except:
        return []

# ------------------ ROUTES ------------------
@app.route("/")
def home():
    return redirect(url_for("main"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        userid = request.form["userid"].strip()
        pw = request.form["password"]
        pw2 = request.form["password2"]
        student_no = request.form.get("student_no", "").strip()
        if not userid or not pw:
            return render_template("register.html", error="아이디와 비밀번호를 입력하세요.")
        if pw != pw2:
            return render_template("register.html", error="비밀번호가 일치하지 않습니다.")
        if len(pw) < 4:
            return render_template("register.html", error="비밀번호는 4자 이상이어야 합니다.")
        grade, classroom = None, None
        if student_no:
            if not (student_no.isdigit() and len(student_no) == 5):
                return render_template("register.html", error="학번은 정확히 5자리 숫자여야 합니다.")
            grade = student_no[0]
            classroom = str(int(student_no[1:3]))
        db = get_db()
        try:
            db.execute("INSERT INTO users (userid, password, grade, classroom, student_no, created_at) VALUES (?, ?, ?, ?, ?, datetime('now'))",
                       (userid, generate_password_hash(pw), grade, classroom, student_no))
            db.commit()
        except sqlite3.IntegrityError:
            return render_template("register.html", error="이미 사용 중인 아이디입니다.")
        session["user"] = userid
        return redirect(url_for("main"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        userid = request.form["userid"]
        pw = request.form["password"]
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE userid=?", (userid,)).fetchone()
        if user and check_password_hash(user["password"], pw):
            session["user"] = userid
            return redirect(url_for("main"))
        return render_template("login.html", error="아이디 또는 비밀번호가 올바르지 않습니다.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("main"))

@app.route("/main")
def main():
    user = session.get("user")
    db = get_db()
    user_data = db.execute("SELECT grade, classroom FROM users WHERE userid=?", (user,)).fetchone() if user else None
    return render_template("main.html", user=user, user_data=user_data)

@app.route("/api/data")
def api_data():
    date = request.args.get("date", datetime.now().strftime("%Y%m%d"))
    grade = request.args.get("grade", "1")
    classroom = request.args.get("classroom", "1")
    start = datetime.strptime(date, "%Y%m%d")
    days = [(start + timedelta(days=i)).strftime("%Y%m%d") for i in range(14)]
    timetable = [{"date": d, "timetable": get_timetable(d, grade, classroom)} for d in days]
    return jsonify({"meal": get_meal(date), "timetable": timetable})

if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)
