from flask import Blueprint, render_template, request, redirect, url_for, session, g
import sqlite3, os
from datetime import datetime

# ===== 블루프린트 설정 =====
board_bp = Blueprint("board", __name__, url_prefix="/board")

# ===== DB 연결 함수 =====
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(os.path.join(os.path.dirname(__file__), "users.db"))
        g.db.row_factory = sqlite3.Row
    return g.db

@board_bp.teardown_request
def close_db(exception):
    db = g.pop("db", None)
    if db:
        db.close()

# ===== 게시판 메인 (목록) =====
@board_bp.route("/<grade>/<classroom>")
def board_list(grade, classroom):
    db = get_db()
    q = request.args.get("q", "").strip()  # 검색어 가져오기

    if q:
        posts = db.execute(
            """
            SELECT * FROM posts
            WHERE grade = ? AND classroom = ?
            AND (title LIKE ? OR author LIKE ?)
            ORDER BY created_at DESC
            """,
            (grade, classroom, f"%{q}%", f"%{q}%")
        ).fetchall()
    else:
        posts = db.execute(
            "SELECT * FROM posts WHERE grade = ? AND classroom = ? ORDER BY created_at DESC",
            (grade, classroom)
        ).fetchall()

    # 로그인 정보 가져오기
    user = session.get("user")
    user_data = None
    if user:
        user_data = db.execute("SELECT * FROM users WHERE userid = ?", (user,)).fetchone()

    return render_template(
        "board_list.html",
        posts=posts,
        grade=grade,
        classroom=classroom,
        user=user,
        user_data=user_data
    )


# ===== 게시글 작성 =====
@board_bp.route("/<grade>/<classroom>/new", methods=["GET", "POST"])
def new_post(grade, classroom):
    db = get_db()
    user = session.get("user")
    user_data = None

    if user:
        user_data = db.execute("SELECT * FROM users WHERE userid = ?", (user,)).fetchone()
    else:
        return redirect(url_for("login"))

    if request.method == "POST":
        title = request.form.get("title")
        content = request.form.get("content")

        if not title or not content:
            return render_template("new_post.html",
                                   error="제목과 내용을 모두 입력하세요.",
                                   user=user,
                                   user_data=user_data,
                                   grade=grade,
                                   classroom=classroom)

        db.execute(
            "INSERT INTO posts (grade, classroom, title, content, author, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (grade, classroom, title, content, user, datetime.now().isoformat())
        )
        db.commit()
        return redirect(url_for("board.board_list", grade=grade, classroom=classroom))

    return render_template(
        "new_post.html",
        user=user,
        user_data=user_data,
        grade=grade,
        classroom=classroom
    )

# ===== 게시글 상세 보기 =====
@board_bp.route("/<grade>/<classroom>/<int:post_id>")
def post_detail(grade, classroom, post_id):
    db = get_db()
    post = db.execute(
        "SELECT * FROM posts WHERE id = ?", (post_id,)
    ).fetchone()

    user = session.get("user")
    user_data = None
    if user:
        user_data = db.execute("SELECT * FROM users WHERE userid = ?", (user,)).fetchone()

    if not post:
        return render_template("error.html", message="존재하지 않는 게시글입니다.",
                               user=user, user_data=user_data)

    return render_template(
        "post_detail.html",
        post=post,
        user=user,
        user_data=user_data,
        grade=grade,
        classroom=classroom
    )
